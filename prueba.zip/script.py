def nombre():
    name = input("Escribe tu nombre: ")
    print ("Hello {}. How are you?".format(name))

nombre()